﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymManagementSystemAdnan
{
    public partial class FormUpdate : Form
    {
        public FormUpdate()
        {
            InitializeComponent();
        }


string con=@"Data Source=SHADOW\SQLEXPRESS;Initial Catalog=GymDataBase;Integrated Security=True"; 
       
        private void populate()
        {

            SqlConnection Con = new SqlConnection(con);
            Con.Open();

            string query = "Select * from MemberTbl";
            SqlDataAdapter sda = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder();
            var ds = new DataSet();
            sda.Fill(ds);
            gunaDataGridView1.DataSource = ds.Tables[0];
            Con.Close();



        }
        private void FormUpdate_Load(object sender, EventArgs e)
        {
            populate();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        
              
                  
                }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }
        int key=0;
        private void gunaDataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            key = Convert.ToInt32(gunaDataGridView1.SelectedRows[0].Cells[0].Value.ToString());
            textBox11.Text = gunaDataGridView1.SelectedRows[0].Cells[0].Value.ToString();
        

            textBox21.Text = gunaDataGridView1.SelectedRows[0].Cells[1].Value.ToString();          
            comboBox11.Text =gunaDataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            textBox31.Text = gunaDataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            textBox41.Text = gunaDataGridView1.SelectedRows[0].Cells[4].Value.ToString();
            comboBox21.Text = gunaDataGridView1.SelectedRows[0].Cells[5].Value.ToString();
        }

        private void gunaAdvenceButton3_Click(object sender, EventArgs e)
        {
            textBox11.Text = "";
            textBox21.Text = "";
            comboBox11.Text = "";
            textBox31.Text = "";
            textBox41.Text = "";
            comboBox21.Text = "";


        }

        private void gunaAdvenceButton4_Click(object sender, EventArgs e)
        {
            Dashboard form = new Dashboard();
            form.Show();
            this.Hide();
        }

        private void gunaAdvenceButton2_Click(object sender, EventArgs e)
        {
            if(key==0)
            {
                MessageBox.Show("Select the member to be deleted");
            }
            else
            {
                try
                {
                    SqlConnection Con = new SqlConnection(con);
                    Con.Open();
                    string query = "delete from MemberTbl where MId=" + key + ";";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Member Delted");
                    populate();
                    Con.Close();
                }catch(Exception Ex)
                {
                    MessageBox.Show(Ex.Message);

                }
            }
        }

        private void gunaAdvenceButton1_Click(object sender, EventArgs e)
        {
            if (key == 0 ||textBox11.Text==""||textBox21.Text==""||comboBox11.Text==""||textBox31.Text==""||textBox41.Text==""||comboBox21.Text=="")
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    SqlConnection Con = new SqlConnection(con);
                    Con.Open();
                    string query = "update MemberTbl set MName='" + textBox11.Text + "',MPhone='" + textBox21.Text + "',MGen='" + comboBox11.Text + "',MAge='" + textBox31.Text + "',MAmount='"+textBox41.Text+"',MTiming='"+comboBox21.Text+"'where MId="+key+";";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Member Delted");
                    populate();
                    Con.Close();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);

                }
            }

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
            
          
        }
    

