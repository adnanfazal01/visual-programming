﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymManagementSystemAdnan
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void gunaAdvenceButton1_Click(object sender, EventArgs e)
        {
            if(gunaTextBox1.Text=="Adnan"&& gunaTextBox2.Text=="123")
            {
                Dashboard db = new Dashboard();
                db.Show();
                this.Hide();

            }
            else
            {
                MessageBox.Show("Invalid Password : Try Again.");
            }
        }
    }
}
