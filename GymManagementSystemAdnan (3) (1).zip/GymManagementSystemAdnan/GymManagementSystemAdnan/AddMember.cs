﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymManagementSystemAdnan
{
    public partial class AddMember : Form
    {
        public AddMember()
        {
            InitializeComponent();
        }

        string con= @"Data Source=SHADOW\SQLEXPRESS;Initial Catalog=GymDataBase;Integrated Security=True";
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void gunaAdvenceButton1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text =="" || textBox2.Text=="" || textBox3.Text=="" || textBox4.Text=="")
            {
                MessageBox.Show("Missing Information");
            }

            else
            {
                try
                {
                    SqlConnection Con = new SqlConnection(con);
                    Con.Open();
                    string query="insert into MemberTbl VALUES('"+textBox1.Text+"','"+textBox2.Text+"','"+comboBox1.SelectedItem.ToString()+"','"+textBox3.Text+"','"+textBox4.Text+"','"+comboBox2.SelectedItem.ToString()+"')";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Member Sucessfully Added");
                    Con.Close();

                }catch(Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void gunaAdvenceButton4_Click(object sender, EventArgs e)
        {
            Dashboard db = new Dashboard();
            db.Show();
            this.Hide();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
