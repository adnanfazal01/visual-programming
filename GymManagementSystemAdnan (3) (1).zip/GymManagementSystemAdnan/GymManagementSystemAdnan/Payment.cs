﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace GymManagementSystemAdnan
{
    public partial class Payment : Form
    {
        string con = @"Data Source=SHADOW\SQLEXPRESS;Initial Catalog=GymDataBase;Integrated Security=True";
       
        private void FillName()
        {
            SqlConnection Con = new SqlConnection(con);
            Con.Open();
            SqlCommand cmd = new SqlCommand("select MName from MemberTbl",Con);
           SqlDataReader rdr;
            rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable(); 
            dt.Columns.Add("MName",typeof(string));
            dt.Load(rdr);
            comboBox2.ValueMember = "MName";
            comboBox2.DataSource = dt;
            Con.Close();
        }
        public Payment()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void gunaAdvenceButton2_Click(object sender, EventArgs e)
        {
          //  textBox1.Text = "";
            textBox2.Text = "";
        }

        private void gunaAdvenceButton3_Click(object sender, EventArgs e)
        {
            Dashboard db = new Dashboard();
            db.Show();
            this.Hide();
        }

        private void Payment_Load(object sender, EventArgs e)
        {
            FillName();
        }

        private void gunaDataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void filterByName()
        {
            SqlConnection Con = new SqlConnection(con);
            Con.Open();
            string query = "Select * from PaymentTbl where PMember='"+textBox1.Text+"'";
            SqlDataAdapter sda = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder();
            var ds = new DataSet();
            sda.Fill(ds);
            gunaDataGridView1.DataSource = ds.Tables[0];
            Con.Close();



        }
        private void populate()
        {
            SqlConnection Con = new SqlConnection(con);
            Con.Open();
            string query = "Select * from PaymentTbl";
            SqlDataAdapter sda = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder();
            var ds = new DataSet();
            sda.Fill(ds);
            gunaDataGridView1.DataSource = ds.Tables[0];
            Con.Close();



        }
        int key = 1;
        private void gunaAdvenceButton1_Click(object sender, EventArgs e)
        {
            SqlConnection Con = new SqlConnection(con);
            if (comboBox2.Text==""||textBox2.Text=="")
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                string payperiode=gunaDateTimePicker1.Value.Month.ToString()+gunaDateTimePicker1.Value.Year.ToString();

                Con.Open();
                SqlDataAdapter sda = new SqlDataAdapter("select count(*) from PaymentTbl where PMember='" + comboBox2.SelectedValue.ToString() + "'and PMonth='" + payperiode + "'", Con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                if (dt.Rows[0][0].ToString()=="1")
                {
                    MessageBox.Show("Already Paid For This Month");
                }
                else
                {
                    string query = "insert into PaymentTbl(PMonth,PMember,PAmount) values('" + payperiode + "','" + comboBox2.SelectedValue.ToString() + "','" + textBox2.Text + "')";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Amount Paid");
                }
                Con.Close();
                populate();
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void gunaAdvenceButton4_Click(object sender, EventArgs e)
        {
            filterByName();
            textBox1.Text = "";
        }

        private void gunaAdvenceButton5_Click(object sender, EventArgs e)
        {
            populate(); 
        }
    }
}
